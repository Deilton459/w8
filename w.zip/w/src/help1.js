const help1 = (prefix) => {

	return `
┣━━━━°❀ ❬ *CRIAR* ❭ ❀°━━━━┓
┃
┣⊱❥ *xd*
┣⊱❥ *pinterest*
┣⊱❥ *anjing*
┣⊱❥ *loli2*
┣⊱❥ *anime*
┣⊱❥ *wolflogo2 <texto | texto>*
┣⊱❥ *quotemaker <tx | wtrmk | tema>*
┣⊱❥ *galaxtext*
┣⊱❥ *textdark*
┣⊱❥ *textblue*
┣⊱❥ *lovemake*
┣⊱❥ *stiltext*
┣⊱❥ *ninjalogo*
┣⊱❥ *party*
┣⊱❥ *rtext*
┣⊱❥ *water*
┣⊱❥ *lionlogo <texto | texto>*
┣⊱❥ *textscreen*
┣⊱❥ *text3d*
┣⊱❥ *epep*
┣⊱❥ *marvelogo <texto | texto>*
┣⊱❥ *snow <texto | texto>*
┣⊱❥ *firetext*

════════════════════
*DEILTON LS* 🤗
*Digite dono para mais info*
════════════════════`
}
exports.help1 = help1


